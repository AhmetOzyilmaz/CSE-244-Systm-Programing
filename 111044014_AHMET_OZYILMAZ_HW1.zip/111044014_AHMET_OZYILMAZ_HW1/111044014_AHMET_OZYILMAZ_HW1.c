/* 
 * File:   main.c
 * Author: ahmet
 *
 * Created on March 1, 2016, 7:14 PM
 */
/* Bu program dosyada aranan anahtar sözcüğü bulup ekrana ve dosyaya yazar */
 /*usage:$  ./111044014_AHMET_OZYILMAZ_HW1 - filename "string"  */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
/*
 * 
 */

int grepfromFile(char* fileName , char* Key);

int main(int argc, char** argv) {

    int fd1;

        if (argc != 3 ) {
            fprintf(stderr, "Usage: grepfromFile  %s %s \n",argv[1],argv[2]);
            return 1;
        }
    
   	if ((fd1 = open(argv[1], O_RDONLY)) == -1) {
            fprintf(stderr, "Failed to open file %s:%s\n", argv[1], strerror(errno));
            return 1;
        }
        
    close(fd1);
    grepfromFile(argv[1],argv[2]);
    
    return (EXIT_SUCCESS);
}

int grepfromFile(char* fileName , char* Key){
    
    int RowCoun = 0,ColumnCoun = 0,check = 2 ,temp = 0,index= 0, i =0 ,j = 0,k=0,
            result = 0,t = 0;
    int keyLenght = 0,currentRow  = 0,lineLenght = 0;
    char red=' ',*line;
    FILE * fp1,*fp2;
    
    fp1= fopen(fileName, "r");
    fp2 = fopen ("gfF.log", "a");
    fprintf(fp2,"%s\n",fileName);

    while(Key[keyLenght] != '\0'){
        keyLenght++;
    }

    
    if (fp2 == NULL ) {
            fprintf(stderr, "Failed to not exist file :%s\n",  strerror(errno));
        }
    else
    {
        while(check!=0)
        {
            check = fscanf(fp1,"%c",&red);
            
            if(red== '\n')
            {
                RowCoun ++;
                if( ColumnCoun> temp)
                    temp = ColumnCoun;
                ColumnCoun=0;
            }
            else
            {
                ColumnCoun++;
            }
            if(check == EOF){
                RowCoun++;
                
                if( ColumnCoun > temp)
                    temp = ColumnCoun;
                else
                    ColumnCoun = temp;
                
                break;
            }
        }
        fclose(fp1);
        fp1= fopen(fileName, "r");
           
        line = (char *) malloc(ColumnCoun+2);
        /*fprintf(stderr,"%d\n",RowCoun);*/
        
        for(t= 0; t<RowCoun ;++t)
        { 
            while(1)/* Line take*/
            {
               check =fscanf(fp1,"%c",&line[index]);
               /*fprintf(stderr,"%c",line[index]);*/
               if(line[index] == '\n' || check == EOF){/*tek bir satırın alındığı kısım*/
                   currentRow++;
                   break;
               }
                index++;
            }
            lineLenght = index;
            
           for(i = 0 ; i < lineLenght  ; i++ ){ 
               for(j = 0 ; j < keyLenght ; ++j  )
               {
                   if(line[j+i] == Key[j] )
                   {
                       result++;
                   }
               }
               if( result ==  keyLenght){/* Anahtar ile kilit cümle uyum kontrolu yapılıypr*/
                   j+=i-keyLenght;

                  fprintf(stderr,"Key Column = %d CURRRENT ROW =  %d\n",j+1,  t+1);
                  fprintf(fp2,"Key Column = %d CURRRENT ROW =  %d\n",j+1,  t+1);

               }
               result= 0;
               
            }
            index =0 ;
            for(k = 0 ; k< ColumnCoun+2; ++k ){/*dinamik arrayin temizlendiği kısım */
                line[k]=' ';
            }
        }
    }
    fclose(fp1);
    fclose(fp2);
    free(line);
   return 1;
}

