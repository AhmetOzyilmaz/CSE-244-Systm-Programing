/*****************************************************************/
/* 11044014_AHMET_OZYILMAZ_HW4 */
/* Çoklu thread ile dosyalardan aranan kelimelerin satır ve sütün numarasını döndürme*/
/*****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/param.h>
#include <signal.h>
#include <termios.h> 
#include <fcntl.h>
#include <sys/wait.h>
#include <pthread.h>

#define BUFSIZE 1024

#define NTHREADS 100
#define LOGFILE "logFile.txt"

int grepfromFile(char* fileName , char* Key,long int ThreadId,int pipefd);
void FindMyKeyWord(char *TargetDirectory, char *KeyWordTwo);
void signalChild( int sig); /* Signal */

static int threadCount=0;/*i */
int ChildCount = 0;
int ChildPid[BUFSIZE];
pthread_t thread_id[NTHREADS];/* stor threads id*/

typedef struct 
{
    char* filN;
    char* KeyN;
    long int ThreadIdN;
    int pipefdN;
} grepFrom ;

int fifo;
char FIFO_FILE[BUFSIZE]; /*main fonksiyonundaki ana fork */
char FIFO_FILE1[BUFSIZE]; /* recursive fonksyionunu içindeki fork  */
char FIFO_FILE2[BUFSIZE]; /*write parent fifo  */

static volatile sig_atomic_t doneflag = 0;
/* ARGSUSED */
static void setdoneflag(int signo)
{
    doneflag = 1;
}

int main (int argc, char * argv[])
{
    int pid ;/* recursive fonksiyonu çağırıcak olan fork*/
    int fdFifo,fdFifo2;

    char memory[BUFSIZE]; /* Okuma islemi icin gerekli string */


    FILE *oup;
    oup = fopen(LOGFILE,"a");

    if(argc != 3){
       fprintf(stderr, "Wrong USAGE : ./11044014_AHMET_OZYILMAZ_HW4 directoryName Keyword\n");
       return -1 ;
    }

    /* Signal icin gerekli kisim. */
    struct sigaction act;
    act.sa_handler = setdoneflag; /* set up signal handler */
    act.sa_flags = 0;
    if ((sigemptyset(&act.sa_mask) == -1) || (sigaction(SIGINT, &act, NULL) == -1))
    {
        perror("Failed to set SIGINT handler");
        return 1;
    }

    sprintf(FIFO_FILE,"FIFO_%ld",(long)getpid());/*Ana fifo*/


    /*fd main fifo descripter*/
    if ((fdFifo=mkfifo(FIFO_FILE, 0666)) == -1)
    {
    /* create a named pipe */
        if (errno != EEXIST)
        {
            fprintf(stderr, "[%ld]:failed to create named pipe %s: %s\n",(long)getpid(), FIFO_FILE, strerror(errno));
            return 1;
        }
    }
    
   // fd = open(FIFO_FILE,O_RDWR); // read

    pid = fork();
    if(pid == -1)
    {
        fprintf(stderr, "ERROR CANNOT FORK");
        exit(1);
    }
    else if(pid == 0 )
    {
        /*fifo oluituruğ child findmy fonksyionunu çağırıcak */
        FindMyKeyWord(argv[1], argv[2]);
        exit(0);
    }
    else
    {

        fdFifo = open(FIFO_FILE,O_RDONLY); // read
               /*child dan gelen verileri log dosyasına basıcak */ 
        memset(memory,0,BUFSIZE);
        //fprintf(stderr, "XXXXXXXXXXXXXXXXXXXXXXXXXX funtion  parent pid %ld  child pid %ld \n",(long)getppid(),(long)getpid());
        while(read(fdFifo,memory,BUFSIZE) > 0)
        {
           fprintf(stderr," %s",memory);/*fifoya yazılıcak root sa log dosyasına yazıcaz */
        }

        //fprintf(stderr, "YYYYYYYYYYYYYYYYYYYYYYYYYYYYY main funtion  parent pid %ld  child pid %ld \n",(long)getppid(),(long)getpid());
    }

        
    while(wait(NULL)>0);

    fclose(oup);
    unlink(FIFO_FILE);
    // wait(NULL);
   // fprintf(stderr, "ZZZZZZZZZZZZZZZZZZZZZZZZZZZ main funtion  parent pid %ld  child pid %ld \n",(long)getppid(),(long)getpid());

     exit(0);
}

void *thread_function(void *dummyPtr)
{

    //fprintf(stderr,"%d\n", threadCount);
    pthread_exit(0);
}

void FindMyKeyWord(char *TargetDirectory, char *KeyWordTwo)
{
    int flag = 0;
    int fdFifo1,fdFifo2,fdFifo;
    int status,fdPipe[2],fdFork,i ;/*fifo descriptor*/
    struct stat stDirInfo,stFileInfo;
    struct dirent * stFiles;
    DIR * stDirIn;
    char szFullName[MAXPATHLEN],szDirectory[MAXPATHLEN];/*sys/param.h ait  MAXPATHLEN*/
    char memory[BUFSIZE];
    grepFrom grepfromFileStruct;
    FILE* fp2;

    fp2= fopen("logFile.txt", "a");  

   // fprintf(stderr, "BORN parent pid %ld  my pid %ld \n",(long)getppid(),(long)getpid());

    strncpy( szDirectory, TargetDirectory, MAXPATHLEN - 1 );

    if (stat( szDirectory, &stDirInfo) < 0){/*Sysyem call information about a file based on its filename. */
        fprintf(stderr, "No such file or directory\n");
        exit(0);
    }

    if (!S_ISDIR(stDirInfo.st_mode))
        exit(0);

    if ((stDirIn = opendir( szDirectory)) == NULL){
        fprintf(stderr, "file or directory Cannot open\n");
        exit(0);
    }


    //  pipe fifo  ismi get pid olucak 

    sprintf(FIFO_FILE1,"FIFO_%ld",(long)getpid());/*Parent pid nin pid ile yeni bir fifo oluşur*/

    /*fd main fifo descripter*/
    if ((fdFifo1=mkfifo(FIFO_FILE1, 0666))== -1)
    {
    /* create a named pipe */
        if (errno != EEXIST)
        {
            fprintf(stderr, "[%ld]:failed to create named pipe %s: %s\n",(long)getpid(), FIFO_FILE1, strerror(errno));
            exit(0);
        }
    }
    //fdFifo1 = open(FIFO_FILE1,O_RDONLY); // read

    if (pipe(fdPipe) == -1)/*directoryler için fifo folder la için pipe */
    {
        perror("Failed to create the pipe");
        exit(EXIT_FAILURE);
    }


    while (( stFiles = readdir(stDirIn)) != NULL) /* klasorun icerigi okunur */
    {
        sprintf(szFullName, "%s/%s", szDirectory, stFiles -> d_name );

        if (lstat(szFullName, &stFileInfo) < 0)
           perror ( szFullName );

        if (S_ISDIR(stFileInfo.st_mode))
        {

            if ((strcmp(stFiles->d_name , "..")) && (strcmp(stFiles->d_name , ".")))
            {
                flag  = 1;

                /* recursive olarak ic icedosyalara girilebilir. */
                //fork child  

                fdFork = fork();
                if(fdFork == -1)
                {
                    fprintf(stderr, "ERROR CANNOT FORK");
                    exit(1);
                }
                else if(fdFork == 0 )
                {
                    /*child process recursive call devam edicek */
                    fprintf(fp2, "%s\n",szFullName );

                    FindMyKeyWord(szFullName, KeyWordTwo);
                    exit(0);
                }
                else
                {
                    /*  parent pid */

                }
            }
        }
        else /* dosya ise */
        {

            flag = 0;

            grepfromFileStruct.filN=szFullName;
            grepfromFileStruct.KeyN=KeyWordTwo;
            grepfromFileStruct.ThreadIdN = 0;
            grepfromFileStruct.pipefdN= fdPipe[1];
            
            threadCount+=1;

           // fprintf(stderr, "grepfromFileStruct.filN, -> %s\n",grepfromFileStruct.filN);

           // grepfromFileStruct.ThreadIdN = pthread_self();
            grepfromFile(grepfromFileStruct.filN, grepfromFileStruct.KeyN,grepfromFileStruct.ThreadIdN,grepfromFileStruct.pipefdN);
            pthread_create( &thread_id[threadCount], NULL, thread_function,&grepfromFileStruct);/*parametre olarak pipe descripter ı verdik*/


        }

    }  
    while ((errno == EINTR) && (closedir(stDirIn) == -1)) ;

    sprintf(FIFO_FILE2,"FIFO_%ld",(long)getppid());/*Parent pid nin pid ile yeni bir fifo oluşur*/

   // fprintf(stderr, "1 parent pid %ld  child pid %ld \n",(long)getppid(),(long)getpid());
   // printf("threadCount %d\n",threadCount );

    //fprintf(stderr, "threadCount %d\n",threadCount );

    for (int i = 0; i < threadCount; ++i)
    {

        pthread_join(thread_id[threadCount],NULL);
    }
    if(flag == 1)
    {
        fdFifo1 = open(FIFO_FILE1,O_RDWR); // read
        
        while(read(fdFifo1,memory,BUFSIZE) > 0)
        {
            fprintf(stderr,"MEmmory %s",memory);/*fifoya yazılanlar okunur */
            write(fdFifo2, memory, strlen(memory));

        }
    }

   // fprintf(stderr, " 2 parent pid %ld  child pid %ld \n",(long)getppid(),(long)getpid());

    close(fdPipe[1]);
    fdFifo = open(FIFO_FILE,O_WRONLY); // write 

    memset(memory,0,BUFSIZE);

    while(read(fdPipe[0],memory,BUFSIZE) > 0)
    {
        //fprintf(stderr,"AHMET %s",memory);/*pipe a yazılanlar okunur*/
        write(fdFifo, memory, strlen(memory));
        fprintf(fp2,"%s\n",memory);
    }
   /// fprintf(stderr, "4 parent pid %ld  child pid %ld \n",(long)getppid(),(long)getpid());

    //close(fdPipe[0]);
    //pipetan fifodan oku 
    //bir üst fifoya yaz get paretnt pid 

    while ((wait(&status)) > 0);

   // fprintf(stderr, "DİE parent pid %ld  my pid %ld \n",(long)getppid(),(long)getpid());

    unlink(FIFO_FILE1);
    fclose(fp2);

}

int grepfromFile(char* fileName , char* Key,long int ThreadId,int pipefd){

    int RowCoun = 0,ColumnCoun = 0,check = 2 ,temp = 0,index= 0, i =0 ,j = 0,k=0,result = 0,t = 0;
    int keyLenght = 0,currentRow  = 0,lineLenght = 0;
    char buf[BUFSIZE];/* Yazma islemi icin gerekli string */

    char red=' ',*line;

    FILE * fp1;

    fp1= fopen(fileName, "r");  

    while(Key[keyLenght] != '\0'){
        keyLenght++;
    }

        while(check!=0)
        {
            check = fscanf(fp1,"%c",&red);
            
            if(red== '\n')
            {
                RowCoun ++;
                if( ColumnCoun> temp)
                    temp = ColumnCoun;
                ColumnCoun=0;
            }
            else
            {
                ColumnCoun++;
            }
            if(check == EOF){
                RowCoun++;
                
                if( ColumnCoun > temp)
                    temp = ColumnCoun;
                else
                    ColumnCoun = temp;
                
                break;
            }
        }
        fclose(fp1);
        fp1= fopen(fileName, "r");
           
        line = (char *) malloc(ColumnCoun+2);
        /*fprintf(stderr,"%d\n",RowCoun);*/
        
        for(t= 0; t<RowCoun ;++t)
        { 

            while(1)/* Line take*/
            {
               check =fscanf(fp1,"%c",&line[index]);
               /*fprintf(stderr,"%c",line[index]);*/
               if(line[index] == '\n' || check == EOF){/*tek bir satırın alındığı kısım*/
                   currentRow++;
                   break;
               }
                index++;
            }
            lineLenght = index;
            
           for(i = 0 ; i < lineLenght  ; i++ ){ 
               for(j = 0 ; j < keyLenght ; ++j  )
               {
                   if(line[j+i] == Key[j] )
                   {
                       result++;
                   }
               }
               if( result ==  keyLenght){/* Anahtar ile kilit cümle uyum kontrolu yapılıypr*/
                   j+=i-keyLenght;

                sprintf(buf," File Name Key %s Column = %d CURRRENT ROW =  %d\n",fileName,j+1,  t+1);
                //fprintf(stderr,"Greep ProcessID %ld fileName %s Key Column = %d CURRRENT ROW =  %d\n",(long)getpid(),fileName,j+1,  t+1);

              //  fprintf(stderr,"%d  %s  \n",pipefd,buf);

                /* main e gerekli veriyi göndericek */
                
               // fprintf(stderr,"My thread Id %ld\n", pthread_self());

                if( write( pipefd, buf, BUFSIZE ) < 0 )
                {
                    perror( "child write to FIFO" );
                }
                 memset(buf,0,BUFSIZE);

               }

               result= 0;
               
            }
            index =0 ;
            for(k = 0 ; k< ColumnCoun+2; ++k ){/*dinamik arrayin temizlendiği kısım */
                line[k]=' ';
            }
        }
    //close(pipefd);

    fclose(fp1);
    free(line);
    return 1;
}

void signalChild( int sig)
{
    printf("\n***** Child killed. *****\n");
    exit( sig );
}