#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/param.h>
#include <signal.h>
#include <termios.h> 
#include <fcntl.h>
#include <sys/wait.h>

#define FIFO_PERMS (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)
#define BUFSIZE 1024
int grepfromFile(char* fileName , char* Key, int fd[2]);
int FindMyKeyWord(char *TargetDirectory, char *KeyWordTwo);
void signalChild( int sig); /* Signal */

static volatile sig_atomic_t doneflag = 0;
/* ARGSUSED */
static void setdoneflag(int signo)
{
    doneflag = 1;
}

int main (int argc, char * argv[])
	{
        char fname[10];
        int fifofd;
        char readFifo[BUFSIZE];



  /* termios.h kutuphanesi ile getchar() kullanilarak anlik karakter okuma da kullanilan islevler.*/
    static struct termios oldt, newt;
    tcgetattr( STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON);          
    tcsetattr( STDIN_FILENO, TCSANOW, &newt);

    /* Signal icin gerekli kisim. */
    struct sigaction act;
    act.sa_handler = setdoneflag; /* set up signal handler */
    act.sa_flags = 0;
    if ((sigemptyset(&act.sa_mask) == -1) || (sigaction(SIGINT, &act, NULL) == -1))
    {
        perror("Failed to set SIGINT handler");
        return 1;
    }



        if(argc != 3){
           fprintf(stderr, "Wrong USAGE : ./11044014_AHMET_OZYILMAZ_HW2 directoryName Keyword\n");
           return -1 ;
        }/*fifo oluituruğ child findmy fonksyionunu çağırıcak */
            FindMyKeyWord(argv[1], argv[2]);

    /*    sprintf(fname, "%d", getpid());
        mkfifo(fname, FIFO_PERMS);
        fifofd = open(fname,O_RDWR ); // read

        while(read(fifofd, readFifo,BUFSIZE) > 0){
            fprintf(stderr, " DEBUG  %s", readFifo);
        }*/

	 return 0;
	}


int FindMyKeyWord(char *TargetDirectory, char *KeyWordTwo)
{
    int MyfifoFD = 0;
    struct stat stDirInfo,stFileInfo;
    struct dirent * stFiles;
    DIR * stDirIn;
    pid_t  pid;
    char szFullName[MAXPATHLEN],szDirectory[MAXPATHLEN];/*sys/param.h ait  MAXPATHLEN*/
    int fd[2];
    int status = 0;
    char bufin[BUFSIZE];
    char buffer[20];

    strncpy( szDirectory, TargetDirectory, MAXPATHLEN - 1 );

    if (stat( szDirectory, &stDirInfo) < 0){/*Sysyem call information about a file based on its filename. */
        fprintf(stderr, "No such file or directory\n");
        return 0;
    }

    if (!S_ISDIR(stDirInfo.st_mode))
        return 0 ;

    if ((stDirIn = opendir( szDirectory)) == NULL){
        fprintf(stderr, "file or directory Cannot open\n");
        return 0 ;
    }


 /*   sprintf(buffer, "%ld",(long)getpid());

   if (mkfifo(buffer, FIFO_PERMS) == -1)
        perror("Failed to create myfifo");

*/


    while (( stFiles = readdir(stDirIn)) != NULL) /* klasorun icerigi okunur */
    {
        sprintf(szFullName, "%s/%s", szDirectory, stFiles -> d_name );

        if (lstat(szFullName, &stFileInfo) < 0)
           perror ( szFullName );

        if (S_ISDIR(stFileInfo.st_mode))
        {
            if ((strcmp(stFiles->d_name , "..")) && (strcmp(stFiles->d_name , ".")))
            {
                /* recursive olarak ic icedosyalara girilebilir. */
                FindMyKeyWord(szFullName, KeyWordTwo);
            }
        }
        else /* dosya ise */
        {
            if (pipe(fd) == -1)
            {
                perror("Failed to create the pipe");
                exit(EXIT_FAILURE);
            }
            

            pid = fork(); /* created child process oluşturulur */

            /* Error check */
            if(pid == -1)
            {
                fprintf(stderr, "ERROR CANNOT FORK");
                exit(1);
            }

            if (pid == 0) 
            {

                printf("pid:%ld , %s\n",(long)getpid(),szFullName);
                signal( SIGINT, signalChild );

                grepfromFile(szFullName, KeyWordTwo,fd);
                exit(1); /* exit ile prosesler oldurulur. */
            }

        }

    }  
    close(fd[1]);


    while(read(fd[0],bufin,BUFSIZE) > 0)
    {
       printf("%s",bufin);/*fifoya yazılıcak root sa log dosyasına yazıcaz */
        //write(MyfifoFD, bufin, strlen(bufin));
    }

    while ((pid = wait(&status)) > 0);
    while ((errno == EINTR) && (closedir(stDirIn) == -1)) ;

    return 0;



}
int grepfromFile(char* fileName , char* Key, int fd[2]){
    
    int RowCoun = 0,ColumnCoun = 0,check = 2 ,temp = 0,index= 0, i =0 ,j = 0,k=0,
            result = 0,t = 0;
    int keyLenght = 0,currentRow  = 0,lineLenght = 0;
    char red=' ',*line;
    char buf[BUFSIZE]; /* for write */


    FILE * fp1,*fp2;
    
    fp1= fopen(fileName, "r");  
   


    while(Key[keyLenght] != '\0'){
        keyLenght++;
    }
    


        while(check!=0)
        {
            check = fscanf(fp1,"%c",&red);
            
            if(red== '\n')
            {
                RowCoun ++;
                if( ColumnCoun> temp)
                    temp = ColumnCoun;
                ColumnCoun=0;
            }
            else
            {
                ColumnCoun++;
            }
            if(check == EOF){
                RowCoun++;
                
                if( ColumnCoun > temp)
                    temp = ColumnCoun;
                else
                    ColumnCoun = temp;
                
                break;
            }
        }
        fclose(fp1);
        fp1= fopen(fileName, "r");
           
        line = (char *) malloc(ColumnCoun+2);
        /*fprintf(stderr,"%d\n",RowCoun);*/
        
        for(t= 0; t<RowCoun ;++t)
        { 
            while(1)/* Line take*/
            {
               check =fscanf(fp1,"%c",&line[index]);
               /*fprintf(stderr,"%c",line[index]);*/
               if(line[index] == '\n' || check == EOF){/*tek bir satırın alındığı kısım*/
                   currentRow++;
                   break;
               }
                index++;
            }
            lineLenght = index;
            
           for(i = 0 ; i < lineLenght  ; i++ ){ 
               for(j = 0 ; j < keyLenght ; ++j  )
               {
                   if(line[j+i] == Key[j] )
                   {
                       result++;
                   }
               }
               if( result ==  keyLenght){/* Anahtar ile kilit cümle uyum kontrolu yapılıypr*/
                   j+=i-keyLenght;

               // fprintf(stderr,"Key Column = %d CURRRENT ROW =  %d\n",j+1,  t+1);
                //fprintf(fp2,"Key Column = %d CURRRENT ROW =  %d\n",j+1,  t+1);
                
                sprintf(buf,"Pid= %ld Key Column = %d CURRRENT ROW =  %d\n",(long)getpid(),j+1,  t+1);
               close(fd[0]);
                write(fd[1], buf, BUFSIZE ); /* write ile pipe yazilir */
                            
               }
               result= 0;
               
            }
            index =0 ;
            for(k = 0 ; k< ColumnCoun+2; ++k ){/*dinamik arrayin temizlendiği kısım */
                line[k]=' ';
            }
        }
    
    fclose(fp1);
    free(line);
   return 1;
}

void signalChild( int sig)
{
        printf("\n***** Child killed. *****\n");
        exit( sig );
}