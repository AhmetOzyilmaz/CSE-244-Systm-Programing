/**********************************************************/
/*****AHMET ÖZYILMAZ 111044014 ***/
/**********************************************************/

/* SERVER KISMI */
/* Yapıldı
/* ---------------
/* 4 çeşit operasyon için 4 adet fonksyioon  
/**********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <ctype.h>
#include <math.h>


#include "parser.h"
#include "test.h"
#include "Takeintegral.h"


#define D_BILLION 1000000000.0
#define D_MILLION 1000000.0
#define MILLION 1000000L
#define NANOSECONDS 1000
#define BUFSIZE 1024

#define CLIENTPID 1024
//operation: One of “+, -, *, /” arithmetical operations.


double opp_add(double num1, double num2);
double opp_sub(double num1, double num2);
double opp_Mul(double num1, double num2);
double opp_Div(double num1, double num2);

void sigCatch( int sig);


int fifo,fifo1;/*clientların bağlanacağı fifo desripter*/

char FIFO_FILE[BUFSIZE]; /* server'in clientlardan veri almasi icin, olusturulacak fifo icin tanimlanan degisken */
char FIFO_FILE1[BUFSIZE] ; /* serverdan clientlara veri gondermek icin, olusturulacak fifo icin tanimlanan degisken */

int client_control=0;/* Client in bagli olup olmadigi controlu */

int ClientPidArr[BUFSIZE];/* client pid lerin tutuldugu array */
int ConnectedClientCount=0; /* baglanan Client sayisi icin */
int MaxNumOfClient = 0; 
double ResultFirstFunction = 0.0 ;
double ResultSecondFunction = 0.0 ;
char *str[5]; /* Clientten alinan string */

int main (int argc, char *argv[])
{
	int i = 0;
	int ClientPid = 0;
	int fd ; /*file descripter*/
	int TimeVale = 0; /*Zaman Hesaplama için Gerekli */
	char memory[BUFSIZE]; /* Okuma islemi icin gerekli string */
	int len = 0 ; /*fifodan gelen string uzunluğu için*/
	pid_t childpid;
	time_t curtime ; /*Şuankki zaman */
	char IntStr[BUFSIZE]; /* sprintf de kullanilan string ,integral icin */
	double IntegralResult; /*Hesaplanan integral sonucu için*/
	struct timeval start , end ;/*client başla  bitiş zamanı için*/
	int argMiliSec; /* Zaman atamalari ve hesabi icin */
	int ClientMilisecond; /* zaman hesabi icin */
	long TimeDifference ;

    if ( argc != 3 )
    {
        fprintf(stderr, "Usage: %s <resolution> -<max # of clients>\n", argv[0]);
        exit(-1);
    }

	/* Ctrl + C   sinyali yakalanir */
    signal( SIGINT, sigCatch);

    /* clientin server programa baglanacagi fifo olusturulur. */
    sprintf(FIFO_FILE,"MAIN_FIFO");

    printf("fifo name %s\n",FIFO_FILE );


	if (fd=mkfifo(FIFO_FILE, 0666) == -1)
	{
	/* create a named pipe */
		if (errno != EEXIST)
		{
			fprintf(stderr, "[%ld]:failed to create named pipe %s: %s\n",(long)getpid(), FIFO_FILE, strerror(errno));
			return 1;
		}
	}

	/* clientin programa baglanacagi fifo acilir */
	printf("FIFO_FILE = %s \n",FIFO_FILE);

	fifo = open( FIFO_FILE, O_RDWR );
	//printf("fifo = %d \n",fifo);
	
	if( fifo < 0 ) {
		perror( "FIFO open" );
	}
    

	while(1)
	{
		//printf(" DEBUG\n");
		TimeVale = 0 ;

		//rintf("DEBUG\n");
      	/* client baglandiginda fifo ya yazılmış olan veri okunur . */
		len = read( fifo, memory, BUFSIZE );

		str[0] = strtok (memory,".");
		
		ClientPid = atoi(str[0]);
		/*-<fi> -<fj> -<time interval> -<operation>*/

		str[1] = strtok(NULL, ".");/* client pid *//*fi*/

		str[2] = strtok(NULL, ".");/* client pid *//*fj*/

		str[3] = strtok(NULL, ".");/* client pid *//*time interval */

		str[4] = strtok(NULL, "\0");/* operation */
		
			//printf(" operation %s\n", str[4]);
		if( len < 0 ) {
			perror( "We Have ne another read message" );
			exit(0);
		}
		else if(len != 0)
		{
						/* arg[2]-<max # of clients>*/
						/* arg[1]-<resolution>*/
			MaxNumOfClient = atoi(argv[2]);
			printf("MaxNumOfClient =  %d\n",MaxNumOfClient );


			ClientPidArr[ConnectedClientCount] = ClientPid ;
			ConnectedClientCount++;

			if(ConnectedClientCount  > MaxNumOfClient )
			{
				fprintf(stderr, " ConnectedClientCount equal to MaxNumOfClient \n");
			}
			else
			{
					printf("ConnectedClientCount  = %d\n",ConnectedClientCount );
				client_control=1;

				if ((childpid = fork()) == -1)
				{
					perror("Failed to fork");
					return 1;
				}


				//printf(".BEN ZAMAN  -<<< %s\n",str[3] );


				if (childpid == 0)  /* The child writes */
				{
					argMiliSec = (atol(argv[1]));/* arguman miliceond cinsinden  tekrar tekrar çözülme zamanı */
					ClientMilisecond = (atol(str[3]));/* clientten gelen milisecond */


						sprintf(FIFO_FILE1,"FIFO_%d",ClientPid);
						printf("SERVER FIFO_FILE = %s \n",FIFO_FILE1);

						/* serverin integral clientine veri gonderdigi fifo olusturulur */
						fifo1 = open( FIFO_FILE1, O_WRONLY );
						if( fifo1 < 0 ) {
							perror( "FIFO open" );
							exit(0);
						}

						curtime = time (NULL);
						printf("Integrate Client[%d] Connect...\n",ConnectedClientCount);
						fputs (ctime (&curtime), stdout);

						if( write( fifo1, IntStr, BUFSIZE ) < 0 )
						{
							perror( "child write to FIFO" );
							exit(0);
						}


						gettimeofday(&start,NULL) ;	/* Zaman baslangici */

					/*	printf("%d\n",ClientMilisecond );
						printf("%d\n",argMiliSec );
						printf("%d\n", ClientMilisecond/argMiliSec);*/
							ResultFirstFunction=fFileParseAndReturnResultFirstFile(str[1],TimeVale);
							ResultSecondFunction=fFileParseAndReturnResultSecondFile(str[2],TimeVale);

						while(1)/*integralin kaç eşit parçaya dönüceğini belirtmiş oluyoruz*/
					    {
					    	//i++;
					    	//printf(" DEBUG %d \n",i );


							TimeVale += argMiliSec;
					    	//i++;
					    	//printf(" DEBUG %d \n",i );

					        usleep(argMiliSec*1000);/* 1000 mili saniye bekler  */

					    	//i++;
					    	//printf(" DEBUG %d \n",i );

							if(str[4][1] == '+' ){IntegralResult = opp_add(ResultFirstFunction,ResultSecondFunction);}
							else if(str[4][1] == '-' ){IntegralResult = opp_sub(ResultFirstFunction,ResultSecondFunction);}
							else if(str[4][1]  == '*' ){IntegralResult = opp_Mul(ResultFirstFunction,ResultSecondFunction);}
							else if(str[4][1] =='/'){IntegralResult = opp_Div(ResultFirstFunction,ResultSecondFunction);}
					    	i++;
					    	//printf(" DEBUG %d \n",i );

							IntegralResult = simpsons(IntegralResult,TimeVale,ClientMilisecond+TimeVale);

					    	//i++;
					    	//printf(" DEBUG %d \n",i );

							//printf("IntegralResult %f\n",IntegralResult );
							printf("IntegralResult %d\n",TimeVale );

							/*Client yapılan işlem sonucu*/

							/* integralli li degerler client e gonderilir */
							sprintf(IntStr,"%ld* IntegralResult = %20f %20d   Integrate Client Pid:[%d]",(long)getpid(),IntegralResult,TimeVale,ClientPid);

					    	//i++;
					    	//printf(" DEBUG %d \n",i );

							if( write( fifo1, IntStr, BUFSIZE ) < 0 )
							{
								perror( "child write to FIFO" );
								exit(0);
							}
					    	//i++;
					    	//printf(" DEBUG %d \n",i );

							gettimeofday(&end,NULL); /* zaman bitisi */
					    	//i++;
					    	//printf(" DEBUG %d \n",i );

							TimeDifference = (end.tv_sec-start.tv_sec)*1000 + (end.tv_usec - start.tv_usec)/1000;/*zaman farkı*/

					    	//i++;
					    	//printf(" DEBUG %d \n",i );
					    	if (TimeDifference >= (ClientMilisecond/argMiliSec))
		  					{
		  						/* Get the current time. */
						    //	i++;
						    	//printf(" DEBUG %d \n",i );

								curtime = time (NULL);
								printf("Integrate Client[%d] Quit...\n",ConnectedClientCount);
								fputs (ctime (&curtime), stdout);

								sprintf(IntStr,"%ld*Integral Client[%d] Quit...\nChild Killed. Child pid : [%ld]\n**Executed time : '%ld' Die Time: %s",(long)getpid(),ConnectedClientCount,(long)getpid(),TimeDifference,ctime (&curtime));
								
								if( write( fifo1, IntStr, BUFSIZE ) < 0 )
								{
								//	    	i++;
								//	    	printf(" DEBUG %d \n",i );

									perror( "child write to FIFO" );
									exit(0);
							}

		  					}
					    }
				}

			}

		}


	}


	close(fifo1);
	close(fifo);
	unlink(FIFO_FILE);
	close(fd);
	unlink(FIFO_FILE1);
	return 0 ; 
}

void sigCatch( int sig)
{

	int i=0;
	char EndStr[BUFSIZE] ="SIGINT";
    close(fifo);

    printf("Ctrl + C (SIGINT) catched\n");

    /* eger pid fifo file ile ayni ise sinyal parenta gelmistir.Fifo */
    if ((long)getpid() == atol(FIFO_FILE))
    {
    	unlink(FIFO_FILE);
    	unlink(FIFO_FILE1);
    	printf("*** Parent Killed ***\n");
    	if (client_control==1)
		{
			while (ConnectedClientCount >  0)
			{
				kill(ClientPidArr[i],SIGINT);
				ConnectedClientCount--;
			}
		}
    }
    sprintf(EndStr,"SIGINT");
    write( fifo1, EndStr, BUFSIZE );

	close(fifo1);
	exit(sig);

}



/*Yapulması gereken 4 operasyon için 4 adet fonksiyon */
double opp_add(double num1, double num2){return num1 + num2;}
double opp_sub(double num1, double num2){return num1 - num2;}
double opp_Mul(double num1, double num2){return num1 * num2;}
double opp_Div(double num1, double num2){return num1 / num2;}
