
#include "Takeintegral.h"


/* fonksiyon x*x seklinde */
double getFunctionValue(double val){
	return val*val*val;
}

double simpsons(int n, double a, double b)
{
	int i;
	double  x, sum;
	double gap = (b - a) / n;
	sum = pow(a,2) + getFunctionValue(b);
	for (i = 1; i < n; i++) {
		x = a + gap * i;
		sum += 2 * (1 + i % 2) * getFunctionValue(x);
	}
	sum *= gap / 3;
	return sum;
}