	/*AHHET ÖZYILMAZ*/


	int fFileParseAndReturnResultFirstFile(char* arguman1,int TimeVale);

	int fFileParseAndReturnResultSecondFile(char* arguman2,int TimeVale);
