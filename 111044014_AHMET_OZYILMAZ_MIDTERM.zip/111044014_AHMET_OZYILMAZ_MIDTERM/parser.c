
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "parser.h"

#define PI 3.14159265

typedef struct Node{
	struct Node* nextItem;
	char* item;
} Node_t;

static int evalOp(Node_t** operandStack, char op, double tValue);
static int tokenizeString(Node_t** stackHead, char inputString[]);
static void push(Node_t** stackHead, char newItem[]);
static void addLast(Node_t** stackHead, char newItem[]);
static int peek(Node_t* stackHead, char peekReturnObject[]);
static int pop(Node_t** stackHead, char popReturnObject[]);
static int isEmpty(Node_t* stackHead);
static void removeAll(Node_t** stackHead);
static int getPrecedence(char op);

static char OPERATORS[]  = {'(',')','+', '-', '*', '/', 's', 'c', 'e', '^'};
static int  PRECEDENCE[] = {-1, -1,  1,   1,   2,   2,   3,   3,   3,   4 };

double evalPostfix(char postfix[], double tValue){
	Node_t* operandStack = NULL;
	Node_t* tokenizedList = NULL;
	char nextToken[20];

	tokenizeString(&tokenizedList, postfix);

	while(tokenizedList != NULL){
		/*Get next token*/
		pop(&tokenizedList,nextToken);
		if(isdigit(nextToken[0]) || nextToken[0] == 't'){/*Operand*/
			push(&operandStack, nextToken);
		}
		else{/*Operator*/
			if(evalOp(&operandStack,nextToken[0],tValue) == -1){
				fprintf(stderr,"Syntax error: Too many operators or operands\n");
				removeAll(&operandStack);
				exit(0);
			}
		}
	} 

	if(pop(&operandStack, nextToken) == -1){
		fprintf(stderr,"Syntax error.\n");
		exit(0);
	}
	else if(!isEmpty(operandStack)){
		fprintf(stderr,"Syntax error.\n");
		removeAll(&operandStack);
		exit(0);
	}

	if(nextToken[0] == 't'){
		return tValue;
	}

	return atof(nextToken);
}

int infixToPostfix(char infix[], char postfix[]){
	Node_t* operatorStack = NULL;
	Node_t* tokenizedList = NULL;
	char nextToken[20];
	char topOp[4];

	if(tokenizeString(&tokenizedList, infix) == -1){
		return -1;
	}

	while(tokenizedList != NULL){
		/*Get next token*/
		pop(&tokenizedList,nextToken);
		if(isdigit(nextToken[0]) || nextToken[0] == 't'){/*Number or t is found*/
			strcat(postfix,nextToken);
			strcat(postfix," ");
		}
		else if(nextToken[0] == '('){
			push(&operatorStack,nextToken);
		}
		else if(nextToken[0] == ')'){
			do{/*pop and append to postfix until left paranthesis*/
				peek(operatorStack,topOp);
				if(topOp[0] == '('){
					pop(&operatorStack,NULL);
					break;
				}
				pop(&operatorStack,topOp);
				strcat(postfix,topOp);
				strcat(postfix," ");
			}while(!isEmpty(operatorStack));

		}
		else{/*Operator*/
			if(isEmpty(operatorStack)){
				push(&operatorStack,nextToken);
			}
			else{/*There are operators in the stack*/
				do{
					peek(operatorStack,topOp);
					if(getPrecedence(nextToken[0]) > getPrecedence(topOp[0])){
						break;
					}
					pop(&operatorStack,topOp);
					strcat(postfix,topOp);
					strcat(postfix," ");
				}while(!isEmpty(operatorStack));
				push(&operatorStack,nextToken);
			}
		}
		
	}/*while*/

	/*Pop remaining operators*/
	while(!isEmpty(operatorStack)){
		pop(&operatorStack,topOp);
		strcat(postfix,topOp);
		strcat(postfix," ");
	}

	return 0;
}

static int evalOp(Node_t** operandStack, char op, double tValue){
	char operandStr[20];
	double lOperand,rOperand,result;

	if(pop(operandStack, operandStr) == -1)
		return -1;
	if(operandStr[0] == 't')
		rOperand = tValue;
	else
		rOperand = atof(operandStr);

	switch(op){
		case 's':
			result = sin(rOperand * PI / 180.0);
			break;
		case 'c':
			result = cos(rOperand * PI / 180.0);
			break;
		case 'e':
			result = exp(rOperand);
			break;
		case '^':
			if(pop(operandStack, operandStr) == -1)
				return -1;
			if(operandStr[0] == 't')
				lOperand = tValue;
			else
				lOperand = atof(operandStr);
			result = pow(lOperand,rOperand);
			break;
		case '+':
			if(pop(operandStack, operandStr) == -1)
				return -1;
			if(operandStr[0] == 't')
				lOperand = tValue;
			else
				lOperand = atof(operandStr);
			result = lOperand + rOperand;
			break;
		case '*':
			if(pop(operandStack, operandStr) == -1)
				return -1;
			if(operandStr[0] == 't')
				lOperand = tValue;
			else
				lOperand = atof(operandStr);
			result = lOperand * rOperand;
			break;
		case '-':
			if(pop(operandStack, operandStr) == -1)
				return -1;
			if(operandStr[0] == 't')
				lOperand = tValue;
			else
				lOperand = atof(operandStr);
			result = lOperand - rOperand;
			break;
		case '/':
			if(pop(operandStack, operandStr) == -1)
				return -1;
			if(operandStr[0] == 't')
				lOperand = tValue;
			else
				lOperand = atof(operandStr);
			result = lOperand / rOperand;
			break;
	}

	sprintf(operandStr,"%f",result);
	push(operandStack,operandStr);

	return 0;
}

static int tokenizeString(Node_t** stackHead, char inputString[]){
	char nextToken[20];
	double num;
	int i=0,j,numOfParanthesis=0;

	/*Tokenize string and add it to stack*/
	while(inputString[i] != '\0'){
		if(isdigit(inputString[i])){
			sscanf(&inputString[i],"%lf",&num);
			sprintf(nextToken,"%f",num);
			/*Add element to stack*/
			while(isdigit(inputString[i]))
				++i;
			if(inputString[i] == '.'){
				++i;
				while(isdigit(inputString[i]))
					++i;
			}
		}
		else if(inputString[i] == 's'){
			if(inputString[i+1] != 'i' || inputString[i+2] != 'n'){
				/*Syntax error*/
				fprintf(stderr, "Syntax error: Unexpected character.\n");
					fprintf(stderr, "%s\n", inputString);
					for(j=0 ; j<i ; ++j)
						fprintf(stderr, " ");
					fprintf(stderr, "^\n" );
				removeAll(stackHead);
				return -1;
			}
			strcpy(nextToken,"sin");
			i += 3;
		}
		else if(inputString[i] == 'c'){
			if(inputString[i+1] != 'o' || inputString[i+2] != 's'){
				/*Syntax error*/
				fprintf(stderr, "Syntax error: Unexpected character.\n");
					fprintf(stderr, "%s\n", inputString);
					for(j=0 ; j<i ; ++j)
						fprintf(stderr, " ");
					fprintf(stderr, "^\n" );
				removeAll(stackHead);
				return -1;
			}
			strcpy(nextToken,"cos");
			i += 3;
		}
		else if(inputString[i] == 'e'){
			if(inputString[i+1] != 'x' || inputString[i+2] != 'p'){
				/*Syntax error*/
				fprintf(stderr, "Syntax error: Unexpected character.\n");
					fprintf(stderr, "%s\n", inputString);
					for(j=0 ; j<i ; ++j)
						fprintf(stderr, " ");
					fprintf(stderr, "^\n" );
				removeAll(stackHead);
				return -1;
			}
			strcpy(nextToken,"exp");
			i += 3;
		}
		else{
			switch(inputString[i]){
				case '(':
					numOfParanthesis += 2;
				case ')':
					--numOfParanthesis;
				case 't':
				case '^':
				case '+':
				case '*':
				case '-':
				case '/': 
					nextToken[0] = inputString[i];
					nextToken[1] = '\0';
					++i;
					break;
				case ' ': 
					++i;
					continue;
				default:/*Syntax error,unexpected character*/
					fprintf(stderr, "Syntax error: Unexpected character.\n");
					fprintf(stderr, "%s\n", inputString);
					for(j=0 ; j<i ; ++j)
						fprintf(stderr, " ");
					fprintf(stderr, "^\n" );
					removeAll(stackHead);
					return -1;
			}
		}
		addLast(stackHead,nextToken);
	}/*while*/

	if(numOfParanthesis != 0){
		fprintf(stderr, "Syntax error: Unmatched paranthesis.\n");
		fprintf(stderr, "%s\n", inputString);
		removeAll(stackHead);
		return -1;
	}

	/*End of tokenize*/
	return 0;
}

/*newItem must be allocated by user*/
static void push(Node_t** stackHead, char newItem[]){
	Node_t* tempNode;

	tempNode = malloc(sizeof(Node_t));
	tempNode->item = malloc(strlen(newItem)+1);
	strcpy(tempNode->item, newItem);
	/*If first add to empty stack, tempNode->nextItem will be NULL*/
	tempNode->nextItem = *stackHead;
	*stackHead = tempNode;
}

static void addLast(Node_t** stackHead, char newItem[]){
	Node_t *tempNode;
	Node_t *tempHead = *stackHead;

	if(*stackHead == NULL){
		push(stackHead,newItem);
		return;	
	}

	tempNode = malloc(sizeof(Node_t));
	tempNode->item = malloc(strlen(newItem)+1);
	tempNode->nextItem = NULL;
	strcpy(tempNode->item, newItem);

	while(tempHead->nextItem != NULL){
		tempHead = tempHead->nextItem;
	}

	tempHead->nextItem = tempNode;
}

/*peekReturnObject must be allocated by user*/
static int peek(Node_t* stackHead, char peekReturnObject[]){
	if(stackHead == NULL){
		fprintf(stderr, "Cannot peek, stack is empty!\n");
		return -1;
	}

	strcpy(peekReturnObject, stackHead->item);

	return 0;
}

/*popReturnObject can be NULL or not*/
static int pop(Node_t** stackHead, char popReturnObject[]){
	Node_t* tempNode;

	if(*stackHead == NULL){
		fprintf(stderr, "Cannot pop, stack is empty!\n");
		return -1;
	}

	tempNode = *stackHead;
	*stackHead = (*stackHead)->nextItem;

	if(popReturnObject != NULL){
		strcpy(popReturnObject, tempNode->item);
	}
	free(tempNode->item);
	free(tempNode);

	return 0;
}

static int isEmpty(Node_t* stackHead){
	return stackHead == NULL;
}

static void removeAll(Node_t** stackHead){
	while(*stackHead != NULL){
		pop(stackHead,NULL);
	}
}

static int getPrecedence(char op){
	int i;
	for(i=0 ; i < 10 ; ++i){
		if(OPERATORS[i] == op)
			return PRECEDENCE[i];
	}
	return 0;
}