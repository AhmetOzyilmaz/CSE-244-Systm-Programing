
 int infixToPostfix(char infix[], char postfix[]);

 double evalPostfix(char postfix[], double tValue);
