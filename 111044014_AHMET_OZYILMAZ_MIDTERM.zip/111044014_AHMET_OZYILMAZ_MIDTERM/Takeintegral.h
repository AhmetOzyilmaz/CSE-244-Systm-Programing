
double getFunctionValue(double val);
double simpsons(int n, double a, double b);
