
/* integral */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>

//#define FIFO_FILE1 "MYFIFO1"
#define BUFSIZE 1024

#define D_BILLION 1000000000.0
#define D_MILLION 1000000.0
#define MILLION 1000000L
#define NANOSECONDS 1000
#define LOGFILE "logfile.txt" /* logFile */

void sigCatch( int sig);

int fifo1,fifo;
int fd1; /* mkfifo icin */
char FIFO_FILE[BUFSIZE];/* Fifo name icin tanimlanan degisken */
char FIFO_FILE1[BUFSIZE];/* Fifo name icin tanimlanan degisken */
char *childKill;/* Serverda bagli oldugu childin pid ini ogrenmek icin tanimlandi */
FILE* logfp;/* logfile icin */
int ConnectedClientCount=0; /* baglanan Client sayisi icin */
int client_control=0;/* Client in bagli olup olmadigi controlu */
int ClientPidArr[BUFSIZE];/* client pid lerin tutuldugu array */


int main (int argc, char *argv[])
{
	int len;/* read kontrolu */
	char buf[BUFSIZE];/* Yazma islemi icin gerekli string */
	char OutpMes[BUFSIZE];/* Okuma islemi icin gerekli string */
	int integral=1; /* integral oldugunu belirten ifade */

	//printf(" %d\n", argc );
    if ( argc != 5 )
    {
        fprintf(stderr, "Usage: %s  -<fi> -<fj> -<time interval> -<operation> ", argv[0]);
        exit(-1);
    }

	/* Ctrl + C   sinyali yakalanir */
    signal( SIGINT, sigCatch);
	sprintf(FIFO_FILE,"%s","MAIN_FIFO");/* Fifo Namel */

	sprintf(buf,"%d.%s.%s.%s.%s",getpid(),argv[1],argv[2],argv[3],argv[4]); /*integral oldugunu belirten ifade -  pid - time  */


	/* Fifo acilir */
	fifo = open(FIFO_FILE, O_WRONLY );

	printf(" fifo %d\n",fifo );
	if( fifo < 0 ) {
		perror( "FIFO open" );
		exit(1);
	}
	/* servera gerekli veriler yazilir */
	if( write( fifo, buf, BUFSIZE ) < 0 )
	{
		perror( "child write to FIFO" );
	}

	/* yazan fifo kapatilir */
	close(fifo);

	sprintf(FIFO_FILE1,"FIFO_%d",getpid());
	printf("CLİENT FIFO_FILE = %s \n",FIFO_FILE1);
	//printf("CLİENT FIFO_FILE = %d \n",getpid());


	if (fd1=mkfifo(FIFO_FILE1, 0666) == -1)
	{
		if (errno != EEXIST)
		{
			fprintf(stderr, "[%ld]:failed to create named pipe %s: %s\n",(long)getpid(), FIFO_FILE1, strerror(errno));
			return 1;
		}
	}

	/* serverdan okuyacak fifo acilir */
	fifo1 = open( FIFO_FILE1, O_RDONLY );

	printf("FIFO_FILE1 - >> %s\n",FIFO_FILE1 );

	if( fifo1 < 0 ) {
		perror( "FIFO open" );
	}

	logfp = fopen(LOGFILE,"a");
	/* Dosya acilmazsa hata verir ve program sonlanir */


    if (logfp == NULL)
    {
        perror("Error opening file");
        exit(1);
    }

  	printf("CALİSİYOR...\n");


	while(1)
	{ 
		/* serverden yazilani okur. */
		len = read( fifo1, OutpMes, BUFSIZE );
		printf("%s\n",OutpMes );
		//printf("%d\n",len );

		if( len <0 ) {
			perror( "child read from FIFO" );
			exit(0);
		}
		else if(len != 0)
		{
			if(!strcmp(OutpMes,"SIGINT"))
			{
				//printf("Bitti!\n");
				printf(" SERVER CLOSED \n");
				close(fifo1);
				unlink(FIFO_FILE1);
				fclose(logfp);
				return 0;
			}
			/* logfile yazar */
			fprintf(logfp,"%s\n", OutpMes);
			/* Clientin bagli oldugu child in Pid'sini alir. */
			childKill = strtok(OutpMes,"*");
		}

	}
/***********************************************/
	close(fifo1);
	fclose(logfp);


	return 0 ; 
}

void sigCatch( int sig)
{

	printf("*** Client killed ***\n");
	fprintf(logfp,"*** Client killed *** PID:[%ld]\n", (long)getpid());
	/* client e sinyal gelince server da bagli oldugu childi oldurur. */
	kill(atol(childKill),SIGINT);
	close(fifo1);
	unlink(FIFO_FILE1);
	fclose(logfp);
	exit(sig);
}
