/*AHHET ÖZYILMAZ*/
/*BU dosya parametre olacak ./simulate -f5- -f2- */
/*fi.txt 5 denklemi fj.txt 2 denklemi işleyip ekrana basar*/


#include "test.h"

#define MAXSIZE 256


	int fFileParseAndReturnResultFirstFile(char* arguman1 , int TimeVale){

		int i = 0,j = 0;
		int status1 = 0;
		char read1,junk='1';
		char input1[MAXSIZE],output1[MAXSIZE];
		double TVALUE = 0;
		FILE* inp1;

		inp1 = fopen("fi.txt","r");/*fi dosyası*/

		memset(input1,0,MAXSIZE);

		memset(output1,0,MAXSIZE);

		int index1 = atoi(&arguman1[2]);/*Kaçıncı fonksiyon alınacağı*/

		/***Birinci dosya için */
		while(index1 > 0)
		{
			fscanf(inp1,"%c",&junk);
			if(junk == '\n')
				index1--;
		}
		while(status1 != EOF )
		{
			status1 = fscanf(inp1,"%c",&read1);
			if(read1 == '\n')
				break;
			if(status1 == EOF )
				break;

			input1[i] = read1;
			i++;
		}

		infixToPostfix(input1,output1);
		//rintf("%s\n",output1 );

		fclose(inp1);
		return evalPostfix(output1, TimeVale);
	}

	int fFileParseAndReturnResultSecondFile(char* arguman2,int TimeVale){

		int i = 0,j = 0;
		int status2 = 0;
		char read2,junk='1';
		char input2[MAXSIZE],output2[MAXSIZE];
		double TVALUE = 0;
		FILE *inp2;

		inp2 = fopen("fj.txt","r");/*fj dosyası*/

		memset(input2,0,MAXSIZE);

		memset(output2,0,MAXSIZE);

		int index2 = atoi(&arguman2[2]);/*Kaçıncı fonksiyon alınacağı*/

		/***Birinci dosya için */
		while(index2 > 0)
		{
			fscanf(inp2,"%c",&junk);
			if(junk == '\n')
				index2--;

		}

		while(status2 != EOF )
		{
			status2 = fscanf(inp2,"%c",&read2);
			if(read2 == '\n')
				break;
			if(status2 == EOF )
				break;

			input2[i] = read2;
			i++;
		}

		

		infixToPostfix(input2,output2);

		fclose(inp2);
		return evalPostfix(output2, TimeVale);
	}

